alter table SAM_ITEMGRADING_T change SUBMITTEDDATE SUBMITTEDDATE datetime null;
commit;