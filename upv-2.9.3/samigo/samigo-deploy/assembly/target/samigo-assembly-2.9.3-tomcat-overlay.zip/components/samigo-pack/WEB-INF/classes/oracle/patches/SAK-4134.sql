alter table SAM_ASSESSMENTGRADING_T modify (SUBMITTEDDATE date null);
commit;
