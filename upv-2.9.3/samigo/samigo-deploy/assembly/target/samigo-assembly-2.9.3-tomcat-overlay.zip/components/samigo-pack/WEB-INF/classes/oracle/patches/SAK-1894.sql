alter table SAM_ITEMGRADING_T
add (ATTEMPTSREMAINING integer);
alter table SAM_ITEMGRADING_T
add (LASTDURATION varchar(36));
