alter table SAM_ITEMGRADING_T add column ATTEMPTSREMAINING integer;
alter table SAM_ITEMGRADING_T add column LASTDURATION varchar(36);
