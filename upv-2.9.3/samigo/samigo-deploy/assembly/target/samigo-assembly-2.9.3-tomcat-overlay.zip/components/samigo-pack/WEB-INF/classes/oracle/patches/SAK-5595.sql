alter table SAM_MEDIA_T add (DURATION varchar(36));
