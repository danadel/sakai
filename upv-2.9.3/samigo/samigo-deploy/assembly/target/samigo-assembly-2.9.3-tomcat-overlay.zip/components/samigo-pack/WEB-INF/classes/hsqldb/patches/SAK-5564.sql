alter table SAM_ITEMGRADING_T alter column SUBMITTEDDATE datetime null;
commit;